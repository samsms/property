<?php

error_reporting(1);
defined('DB_SERVER') ? null : define("DB_SERVER", "localhost");
defined('DB_USER')   ? null : define("DB_USER", "sam");
defined('DB_PASS')   ? null : define("DB_PASS", "samsaf");
defined('DB_NAME')   ? null : define("DB_NAME", "techsava_property_htest");
date_default_timezone_set("Africa/Nairobi");
$root="https://localhost/property-rivercourt-test/";

?> 
