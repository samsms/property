<?php 
//require '/confirmation/';
//require '/validation/';
require 'functions.php';

//echo generateToken();

echo registerURL();



?>

