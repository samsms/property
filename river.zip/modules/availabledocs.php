<?php

include 'functions.php';
echo availabledocslegal();
?>
