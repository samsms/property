<?php
       include 'functions.php';
       echo uploadlegal();
