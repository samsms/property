<?php
require_once'functions.php';

#echo generateToken();
#echo registerURL();
echo simulateC2B(100, '254708374149');

?>