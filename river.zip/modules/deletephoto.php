<?php
include 'functions.php';

$photoid=$_REQUEST['photoid'];
echo deletephotos($photoid);

?>
