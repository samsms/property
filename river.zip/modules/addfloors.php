<?php
include 'functions.php';
echo addfloors(52,3);
?>